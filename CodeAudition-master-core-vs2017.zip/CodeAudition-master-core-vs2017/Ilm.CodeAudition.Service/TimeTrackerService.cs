﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using Ilm.CodeAudition.Service.Models;
using Microsoft.EntityFrameworkCore;

namespace Ilm.CodeAudition.Service
{
    public class TimeTrackerService
    {
        public void HelloWorld()
        {
            Console.WriteLine("Hello World!");
        }

        public void Save(Timesheet timesheet)
        {
            //var db = new Database();
            //var dbTimesheet = db.Timesheets.Find(timesheet.Id);
            //dbTimesheet.Monday = timesheet.Monday;
            //dbTimesheet.Tuesday = timesheet.Tuesday;
            //dbTimesheet.Wednesday = timesheet.Wednesday;
            //dbTimesheet.Thursday = timesheet.Thursday;
            //dbTimesheet.Friday = timesheet.Friday;
            //dbTimesheet.Total = timesheet.Total;
            //db.SaveChanges();

            //swetha
            var optionsBuilder = new DbContextOptionsBuilder<TimesheetDBContext>();
            optionsBuilder.UseSqlite("Filename=Ilm.CodeAudition.Service.db");
            TimesheetDBContext db = new TimesheetDBContext(optionsBuilder.Options);
            var dbTimeSheet = db.Timesheets.Find(timesheet.Id);            
            dbTimeSheet.Monday = timesheet.Monday;
            dbTimeSheet.Tuesday = timesheet.Tuesday;
            dbTimeSheet.Wednesday = timesheet.Wednesday;
            dbTimeSheet.Thursday = timesheet.Thursday;
            dbTimeSheet.Friday = timesheet.Friday;
            dbTimeSheet.Total = timesheet.Total;
            db.SaveChanges();
            //swetha
        }

        public IList<Timesheet> GetAll()
        {
            //var db = new Database();
            //return db.Timesheets.ToList();

            //swetha
            var optionsBuilder = new DbContextOptionsBuilder<TimesheetDBContext>();
            optionsBuilder.UseSqlite("Filename=Ilm.CodeAudition.Service.db");
            TimesheetDBContext db = new TimesheetDBContext(optionsBuilder.Options);
            return db.Timesheets.ToList();
            //swetha
        }
    }
}
